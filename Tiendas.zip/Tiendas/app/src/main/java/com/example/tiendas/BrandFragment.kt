package com.example.tiendas

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [BrandFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class BrandFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    private lateinit var recyclerMarca: RecyclerView
    private lateinit var deportes: RecyclerView
    private lateinit var joyerias: RecyclerView
    private lateinit var juegos: RecyclerView
    private lateinit var lineablanca: RecyclerView
    private lateinit var electronica: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_category, container, false)
        recyclerMarca = view.findViewById(R.id.recyclerCategory)
        iniciarRecyclerM()
        return view
    }

    private fun getDeportes(): MutableList<Lista>{
        val deportes: MutableList<Lista> = mutableListOf()
        deportes.add(Lista("Nike" ))
        deportes.add(Lista("Adidad" ))
        deportes.add(Lista("Under Armor" ))
        return deportes
    }

    private fun getJoyerias(): MutableList<Lista>{
        val joyerias: MutableList<Lista> = mutableListOf()
        joyerias.add(Lista("Amore Mio" ))
        joyerias.add(Lista("Tous" ))
        joyerias.add(Lista("Swarovski" ))
        return joyerias
    }

    private fun getJuegos(): MutableList<Lista>{
        val juegos: MutableList<Lista> = mutableListOf()
        juegos.add(Lista("Xbox" ))
        juegos.add(Lista("Play Station" ))
        juegos.add(Lista("Nintendo" ))
        return juegos
    }

    private fun getLineaBlanca(): MutableList<Lista>{
        val lineablanca: MutableList<Lista> = mutableListOf()
        lineablanca.add(Lista("Whirlpool" ))
        lineablanca.add(Lista("Mabe" ))
        lineablanca.add(Lista("Hisense" ))
        return lineablanca
    }

    private fun getElectronica(): MutableList<Lista>{
        val electronicos: MutableList<Lista> = mutableListOf()
        electronicos.add(Lista("Samsung" ))
        electronicos.add(Lista("Apple" ))
        electronicos.add(Lista("Xiaomi" ))
        return electronicos
    }

    private fun iniciarRecyclerM() {
        deportes.adapter = AdaptadorRecycler(context, getDeportes())
        deportes.setOnClickListener { adapterView, view, i, l ->
            val deporte = adapterView.getItemPosition(i) as Lista
        }

        joyerias.adapter = AdaptadorRecycler(context, getDeportes())

        juegos.adapter = AdaptadorRecycler(context, getDeportes())

        lineablanca.adapter = AdaptadorRecycler(context, getDeportes())

        electronica.adapter = AdaptadorRecycler(context, getDeportes())
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment BrandFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            BrandFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}