package com.example.tiendas

import android.content.Context
import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AdaptadorMarcas(private val context: Context,
                      private val marcas: MutableList<Lista>) :
                RecyclerView.Adapter<AdaptadorMarcas.ViewHolder>(){

                class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
                    var txvMarcas: TextView = itemView.findViewById(R.id.categoria)
                }
}