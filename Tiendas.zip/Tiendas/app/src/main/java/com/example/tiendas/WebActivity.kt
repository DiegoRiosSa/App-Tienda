package com.example.tiendas

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class WebActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web)
    }
}