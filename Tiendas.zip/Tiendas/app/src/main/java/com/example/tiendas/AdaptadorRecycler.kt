package com.example.tiendas

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.tiendas.R

class AdaptadorRecycler(private val context: Context?,
                        private val categories: MutableList<Lista>) :
    RecyclerView.Adapter<AdaptadorRecycler.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)  {
        var txvCategoria: TextView = itemView.findViewById(R.id.categoria)

        fun bind(category: Lista) {
            itemView.setOnClickListener {
                if (true) { ->

                }
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutInflater: LayoutInflater = LayoutInflater.from(context)
        val view = layoutInflater.inflate(R.layout.card, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val category: Lista = categories[position]
        holder.txvCategoria.text = category.categoria
        holder.bind(category)
    }

    override fun getItemCount(): Int {
        return categories.size
    }

}