package com.example.tiendas

class Lista(var categoria: String) {

}